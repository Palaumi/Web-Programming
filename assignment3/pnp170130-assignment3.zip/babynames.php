<?php
    $queryString = "";

    if(isset($_GET['year']) && !$_GET['year'] == "") {
        $queryString = " WHERE year = " . $_GET['year'];
    }
    if(isset($_GET['gender']) && !$_GET['gender'] == "") {
        if($queryString == "")  {
            $queryString = " WHERE gender = '" . $_GET['gender'] . "'";
        }
        else    {
            $queryString = $queryString . " AND gender = '" . $_GET['gender'] . "'";
        }
     }

    $con = mysqli_connect('localhost', 'root', 'root', 'hw3');
    
    if(!$con)   {
        die('Could not connect: ' + mysqli_error($con));
    }
    else    {
       // mysqli_select_db($con, "hw3");
        $sql = 'SELECT name, year, gender, ranking FROM babynames' . $queryString . ' ORDER BY year DESC, ranking ASC;';
        $result = mysqli_query($con, $sql);
        echo "<table><tr><th>Name</th><th>Ranking</th><th>Gender</th><th>Year</th></tr>";
        while($row = mysqli_fetch_array($result))   {
            echo "<tr>";
            echo "<td>" . $row["name"] . "</td>";
            echo "<td>" . $row["ranking"] . "</td>";
            echo "<td>" . $row["gender"] . "</td>";
            echo "<td>" . $row["year"] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        mysqli_close($con);
    }

?>